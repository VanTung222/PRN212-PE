﻿namespace AirConditionerShop.BLL
{
    public class Class1
    {

    }
}
