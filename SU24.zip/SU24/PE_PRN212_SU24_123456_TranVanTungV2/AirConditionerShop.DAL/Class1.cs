﻿namespace AirConditionerShop.DAL
{
    public class Class1
    {

    }
}
