﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AirConditionerShop_TranVanTung
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    // class mainwindow kế thừa class wwindow - class có sẵn trong .NET SDK

    // để chuyển đổi từ xaml sang c# thì sử dụng công cụ xamlc.exe
    //dùng phím F7 từ design -> chuyển sang code
    // phím shift+F7 để chuyển từ code sang design
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            detailWindow d = new();
            d.Show();
        }
    }
}